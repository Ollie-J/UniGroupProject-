// Fill out your copyright notice in the Description page of Project Settings.


#include "MyCharacter.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"


AMyCharacter::AMyCharacter()
{
	//constructor default values and setting up camera/varaibles
	PrimaryActorTick.bCanEverTick = true;
 	WalkSpeed = 400.f;
	SprintSpeed = 600.f;
	TurnAmount = 0.0f;
	BJumping = false;
	GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
	GetCharacterMovement()->JumpZVelocity = 350.f;

	//Cameras Spring Arm
	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringArm->SetupAttachment(RootComponent);
	SpringArm->TargetArmLength = 700.0f;
	SpringArm->TargetOffset = FVector(0.f, 000.f, 200.f);
	SpringArm->bEnableCameraLag = true;
	SpringArm->bEnableCameraRotationLag = true;
	SpringArm->CameraLagSpeed = 10.0f;
	SpringArm->bUsePawnControlRotation; //camera will rotate with controller

	//Camera that follows player
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	FollowCamera->SetupAttachment(SpringArm, USpringArmComponent::SocketName); //attaching camera to spring arm
	FollowCamera->bUsePawnControlRotation = false; //camera doesnt rotate relative to the spring arm
}


void AMyCharacter::BeginPlay()
{
	Super::BeginPlay();
	
}


void AMyCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


void AMyCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAxis("MoveForward", this, &AMyCharacter::MoveForward);
	PlayerInputComponent->BindAxis("Turn", this, &AMyCharacter::Turn);

	PlayerInputComponent->BindAction("Sprint", IE_Pressed, this, &AMyCharacter::StartRun);
	PlayerInputComponent->BindAction("Sprint", IE_Released, this, &AMyCharacter::EndRun);
}

void AMyCharacter::MoveForward(float InputAxis)
{
	if(InputAxis !=0)
	{
		AddMovementInput(GetActorForwardVector(), InputAxis);
	}
}

void AMyCharacter::Turn(float InputAxis)
{
	if(InputAxis !=0)
	{
		TurnAmount += InputAxis;
		Controller->ClientSetRotation(FRotator(0.f, TurnAmount,0.f));
		
	}
}

void AMyCharacter::StartRun()
{
	GetCharacterMovement()->MaxWalkSpeed=SprintSpeed;
}

void AMyCharacter::EndRun()
{
	GetCharacterMovement()->MaxWalkSpeed=WalkSpeed;
}

