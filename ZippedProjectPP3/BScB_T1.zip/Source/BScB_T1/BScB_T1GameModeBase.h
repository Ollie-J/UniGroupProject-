// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "BScB_T1GameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class BSCB_T1_API ABScB_T1GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
