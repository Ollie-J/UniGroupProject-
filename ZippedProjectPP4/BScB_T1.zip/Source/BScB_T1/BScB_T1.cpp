// Copyright Epic Games, Inc. All Rights Reserved.

#include "BScB_T1.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, BScB_T1, "BScB_T1" );
